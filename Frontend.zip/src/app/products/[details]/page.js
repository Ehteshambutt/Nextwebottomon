const ProductDetails = ({ params }) => {
  return (
    <div className="bg-gray-300">
      <h1>Products Details {params.details}</h1>
      
    </div>
  );
};

export default ProductDetails;
